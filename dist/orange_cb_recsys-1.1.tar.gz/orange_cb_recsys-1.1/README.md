[![Build Status](https://travis-ci.com/m3ttiw/orange_cb_recsys.svg?branch=master)](https://travis-ci.com/m3ttiw/Framework_CBRS_py)&nbsp;&nbsp;[![Coverage Status](https://coveralls.io/repos/github/m3ttiw/orange_cb_recsys/badge.png?branch=master)](https://coveralls.io/github/m3ttiw/orange_cb_recsys?branch=master)&nbsp;&nbsp;![Docker Cloud Build Status](https://img.shields.io/docker/cloud/build/rbarile17/framework_dependencies)&nbsp;&nbsp;[![Python 3.8](https://img.shields.io/badge/python-3.8-blue.svg)](https://www.python.org/downloads/release/python-382/)

# Framework_CBRS_py
